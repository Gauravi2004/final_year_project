from django.contrib import admin
from .models import HandImage,SentenceToVideo
# Register your models here.
admin.site.register(HandImage)
admin.site.register(SentenceToVideo)